package com.bookstore;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/bookstore")
public class BookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private List<Book> bookList = new ArrayList<>();

    public BookServlet() {
        // Sample book data
        bookList.add(new Book("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 10.99, true));
        bookList.add(new Book("1984", "George Orwell", "Dystopian", 8.99, true));
        bookList.add(new Book("Clean Code", "Robert C. Martin", "Programming", 30.99, false));
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("books", bookList);
        request.getRequestDispatcher("/books.jsp").forward(request, response);
    }
}

